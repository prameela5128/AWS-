package ssm_lambda.example;

import com.amazonaws.services.lambda.runtime.Context;
//import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import software.amazon.lambda.powertools.parameters.ParamManager;
import software.amazon.lambda.powertools.parameters.SSMProvider;

public class Handler {
	
	public Object handleRequest(String ParameterKey) {
		//String ParameterKey = 
		SSMProvider ssmProvider = ParamManager.getSsmProvider();
		String usersParam = ssmProvider.get(ParameterKey);
		System.out.println(usersParam);
		return null;
	}
}
