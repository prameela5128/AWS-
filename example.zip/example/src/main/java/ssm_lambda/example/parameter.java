package ssm_lambda.example;

public class parameter {
	
	private String ParameterKey;

	public String getParameterKey() {
		return ParameterKey;
	}

	public void setParameterKey(String parameterKey) {
		ParameterKey = parameterKey;
	}

}
