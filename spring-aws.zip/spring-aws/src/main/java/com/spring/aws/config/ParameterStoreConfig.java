/**
 * 
 */
package com.spring.aws.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.amazonaws.auth.AWSCredentials;
import com.amazonaws.auth.AWSCredentialsProvider;
import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.BasicAWSCredentials;
import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagement;
import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagementClientBuilder;

@Configuration
public class ParameterStoreConfig {

	@Value("${cloud.aws.credentials.accessKey}")
	private String acessKey;

	@Value("${cloud.aws.credentials.secretKey}")
	private String secretKey;
	
	@Value("${cloud.aws.region}")
	private String region;

	@Value("${tiaasID}")
	private String tiaasID;

	
	@Bean
	public AWSCredentials credential() {
		System.out.println("I am saying hello");
		return new BasicAWSCredentials(acessKey, secretKey);
	}

	@Bean
	public AWSSimpleSystemsManagement systemManager() {

		AWSCredentialsProvider credentials = new AWSStaticCredentialsProvider(credential());

		return AWSSimpleSystemsManagementClientBuilder.standard().withCredentials(credentials).withRegion(region).build();
	}
}