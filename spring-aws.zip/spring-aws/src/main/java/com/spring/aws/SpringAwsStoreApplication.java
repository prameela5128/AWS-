package com.spring.aws;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAwsStoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAwsStoreApplication.class, args);
	}

}