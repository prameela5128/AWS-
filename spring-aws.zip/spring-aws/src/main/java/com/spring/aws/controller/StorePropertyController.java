/**
 * 
 */
package com.spring.aws.controller;



/*import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;

import java.util.List;
import java.util.Properties;
import org.springframework.beans.factory.annotation.Value;
*/
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.ConfigurableEnvironment;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.amazonaws.services.simplesystemsmanagement.AWSSimpleSystemsManagement;
import com.amazonaws.services.simplesystemsmanagement.model.GetParameterRequest;
import com.amazonaws.services.simplesystemsmanagement.model.GetParameterResult;
import com.amazonaws.services.simplesystemsmanagement.model.Parameter;
//import com.spring.aws.config.ParameterStorePropertySource;


@RestController
public class StorePropertyController {

	@Autowired
	private ConfigurableEnvironment env;

	@Autowired
	private AWSSimpleSystemsManagement awsSimpleSystemsManagement;

	/*@Value("${tiaasID}")
	private String storeValue;

	@Value("${securehello}")
	private String secureStoreValue;
	
	@GetMapping("store/value")
	public String getStoreValue() {
		return storeValue;
	}
	
	@GetMapping("store/value/secure")
	public String getSecureStoreValue() {
		return secureStoreValue;
	}*/
	
	@GetMapping("store/parameter/default")
	public Parameter getParameterFromSSMByName() {

		GetParameterRequest parameterRequest = new GetParameterRequest();
		parameterRequest.withName("/config/awsstore/tiaasID").setWithDecryption(Boolean.valueOf(true));
		GetParameterResult parameterResult = awsSimpleSystemsManagement.getParameter(parameterRequest);

		return parameterResult.getParameter();
	}

	
	@GetMapping("store/env")
	public String getClientIDs() {

		String parameter = env.getProperty("tiaasID");
		String TiaasID = env.getProperty("/config/awsstore/tiaasID");
		return "tiaasID:  " + parameter + ", TiaasID:  " + TiaasID;

	}
	
	
	@GetMapping("store/validate")
	public String ValidateValue(@RequestParam(name="id") String tiaasID) {
		//List<String> ids=Arrays.asList(env.getProperty("/config/awsstore/tiaasID"));
		if(env.getProperty("/config/awsstore/tiaasID").contains(tiaasID)) {
			return "Client ID Exists";
		}
			return "Client Id doesn't exists in the list of clients";
	}

	
	
	
	
	
	
	/*@GetMapping("store/all")
	public Properties getAllProperties() {
		MutablePropertySources propertySources = env.getPropertySources();
		Properties props = new Properties();

		for (PropertySource<?> nestedSource : propertySources) {

			System.out.println("Property Source Name: " + nestedSource.getName() + " : ");

			if (nestedSource instanceof EnumerablePropertySource) {

				@SuppressWarnings("rawtypes")
				EnumerablePropertySource eps = (EnumerablePropertySource) nestedSource;

				for (String propName : eps.getPropertyNames()) {
					System.out.println("\t" + propName + " = " + eps.getProperty(propName));
					props.setProperty(propName, env.getProperty(propName));
				}
			} else if (nestedSource instanceof MapPropertySource) {

				MapPropertySource eps = (MapPropertySource) nestedSource;

				for (String propName : eps.getPropertyNames()) {
					System.out.println("\t" + propName + " = " + eps.getProperty(propName));
					props.setProperty(propName, env.getProperty(propName));
				}
			} else if (nestedSource instanceof ParameterStorePropertySource) {

				ParameterStorePropertySource psps = (ParameterStorePropertySource) nestedSource;

				System.out.println(psps.getSource());

			}
		}

		return props;
	}*/

}