package ssm_lambda.example;

import java.util.Base64;

import com.amazonaws.services.lambda.runtime.Context;
//import com.amazonaws.services.lambda.runtime.RequestHandler;
import com.amazonaws.services.lambda.runtime.RequestHandler;

import software.amazon.lambda.powertools.parameters.ParamManager;
import software.amazon.lambda.powertools.parameters.SSMProvider;
import software.amazon.lambda.powertools.parameters.SecretsProvider;
import software.amazon.lambda.powertools.parameters.transform.Transformer;

public class Handler {
	
	public Object ssm(String ParameterKey) { 
		SSMProvider ssmProvider = ParamManager.getSsmProvider();
		String usersParam = ssmProvider.get(ParameterKey);
		System.out.println("Key  : "+ParameterKey+"  value  : "+usersParam);
		return usersParam;
	}
	
	public Object ssmWithDecryption(String ParameterKey) {
		
		SSMProvider ssmProvider = ParamManager.getSsmProvider();
		String usersParam = ssmProvider.withDecryption().get(ParameterKey);
		System.out.println("Key  : "+ParameterKey+"  value  : "+usersParam);
		return usersParam;
	}
	
	public Object secretsManager(String ParameterKey) {
		
		SecretsProvider secretsProvider = ParamManager.getSecretsProvider();
		String usersParam = secretsProvider.get(ParameterKey);
		System.out.println("Key  : "+ParameterKey+"  value  : "+usersParam);
		return usersParam;
	}
	
	public Object secretsManagerWithDecryption(String ParameterKey) {
		
		SecretsProvider secretsProvider = ParamManager.getSecretsProvider();
		String usersParam = secretsProvider.get(ParameterKey);
		String decodeValue= new String(Base64.getDecoder().decode(secretsProvider.get(ParameterKey)));
		System.out.println("Key  : "+ParameterKey+"  value  : "+decodeValue);
		return decodeValue;
	}
	
	
}
