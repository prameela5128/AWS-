# Tyk Pro Demo using Docker

This compose file is designed to provide a quick, simple demo of the Tyk stack, this includes Tyk Gateway, Tyk Dashboard, Tyk Portal, Mongo, & Redis.

This repo great for proof of concept and demo purpose, but if you want test performance, you need to move each component to separate machine, following our documentation https://tyk.io/docs/.

## Step 1: Add your dashboard license

Create `.env` file `cp .env.example .env`. Then add your license string to `TYK_DB_LICENSEKEY`.

## Step 2: Initialise the Docker containers

Run docker compose:

With a `Mongo` database:
```
$ docker-compose up
```

With a `PostgreSQL` database:
```
$ docker-compose -f ./docker-compose.yml -f ./docker-compose.postgres.yml up
```

Please note that this command may take a while to complete, as Docker needs to download and provision all of the containers.

This will run in non-daemonised mode so you can see all the output.

## Step 3: Bootstrap the Tyk installation

Bootstrap the instance:

Open your browser to http://localhost:3000.  You will be presented with the Bootstrap UI to create your first organisation and admin user.

## Tear down

To delete all containers as well as remove all volumes from your host:

Mongo:
```
$ docker-compose down -v
```

PostgreSQL:
```
$ docker-compose -f ./docker-compose.yml -f ./docker-compose.postgres.yml down -v
```