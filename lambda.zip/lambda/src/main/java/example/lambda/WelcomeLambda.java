package example.lambda;

import com.amazonaws.services.lambda.runtime.Context;
import com.amazonaws.services.lambda.runtime.RequestHandler;


public class WelcomeLambda implements RequestHandler<Object, Object> {
	
	public Object handleRequest(Object input, Context context) {
		// TODO Auto-generated method stub
		System.out.println("Hello world");
		return null;
	}
  
	
}
